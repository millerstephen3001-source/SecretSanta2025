HOW TO HOST ON GITHUB PAGES:

1. Go to https://github.com
2. Create a new public repository named "SecretSanta2024"
3. Upload ALL files from this ZIP into the repo
4. Go to Settings -> Pages
5. Under "Source", choose: main branch / root folder
6. Save
7. Your site will appear at:

https://YOURUSERNAME.github.io/SecretSanta2024

Password: santa2024
